<style>
.bs-callout {
    margin: 20px 0;
    padding: 15px 30px 15px 15px;
    border-left: 5px solid #eee;
}
.bs-callout-info {
    background-color: #E4F1FE;
    border-color: #22A7F0;
}

</style>
			<?php
			global $wpdb;
			global $current_user;
			global $wp_roles;
			$ii=1;
			
			
			?>
			<div class="bootstrap-wrapper">
				<div class="welcome-panel container-fluid">
						<div class="row">
							
							<div class="col-md-12"><h3 class="page-header"><?php _e('Report Fields','epfitness'); ?>  <br /><small> &nbsp;</small> </h3>
							</div>
						</div> 
						<div id="success_message">	</div>
						
						
						
							
							
						<div class="panel panel-info">
						<div class="panel-heading"><h4><?php _e('Report Fields','epfitness'); ?>   </h4></div>
						<div class="panel-body">	
							
							
							<form id="dir_fields" name="dir_fields" class="form-horizontal" role="form" onsubmit="return false;">	
										<div class="row">
												
												<div class="col-sm-2 ">		
													<label > <?php _e('Report Title','epfitness');?>: </label>
												</div>
												<div class="col-sm-3">		
													<input type="text" name="report_title1" id="report_title1" value="<?php echo (get_option('epfitness_report_title1')==''?"FITNESS": get_option('epfitness_report_title1'));?>">
												</div>
												<div class="col-sm-3 form-group">		
													<input type="text" name="report_title2" id="report_title2" value="<?php echo (get_option('epfitness_report_title2')==''?"REPORT":get_option('epfitness_report_title2') );?>">
												</div>
													
										</div>	
										
										<div class="row">
												<div class="col-sm-5 ">										
													<h4><?php _e('Who can create/add Report','epfitness'); ?>  </h4>
												</div>
										</div>	
										
											
										<div class="row">
												<div class="col-sm-4 ">	
													<?php
													$report_access=get_option('epfitness_report_access');	
													if(trim($report_access)==''){$report_access='users';}				
													?>
														<label>												
														<input type="radio" name="report_access" id="report_access" value='trainer' <?php echo ($report_access=='trainer' ? 'checked':'' ); ?> ><?php _e(' Only Trainer+ Admin can add report for user','epfitness');  ?>
														</label>
												</div>	
												<div class="col-sm-2">	
													<label>	<?php _e('Set Trainer User Role','epfitness');  ?>  </label>
												</div>	
												<div class="col-sm-3">
																<?php	
																$trainer_role=get_option('epfitness_trainer_role');	
																?>
														<select name="trainer_role" id ="trainer_role" class="form-control">
															<?php											
																foreach ( $wp_roles->roles as $key=>$value ){
																	echo'<option value="'.$key.'"  '.($trainer_role==$key? " selected" : " ") .' >'.$key.'</option>';	
																		
																}
																  ?>	
														</select>												
												</div>
														
												
											</div>		
										<div class="row">	
												<div class="col-sm-12 ">	
													
														<label>												
														<input type="radio" name="report_access" id="report_access" value='users' <?php echo ($report_access=='users' ? 'checked':'' ); ?> ><?php _e(' User can add his/her own report','epfitness');  ?>
														</label>
												</div>	
												
										</div>														
										<div class="row">
												<div class="col-sm-5 ">										
													<h4><?php _e('Post Meta Name','epfitness'); ?> </h4>
												</div>
												<div class="col-sm-5">
													<h4><?php _e('Display Label','epfitness'); ?> </h4>									
												</div>
												<div class="col-sm-2">
													<h4><?php _e('Action','epfitness'); ?> </h4>													
												</div>					  
										</div>
										
																 
									
											<div id="custom_field_div">			
														<?php
														
														
														$default_fields = array();
															$field_set=get_option('ep_fitness_report_fields' );
															
															
														if($field_set!=""){ 
																$default_fields=get_option('ep_fitness_report_fields' );
														}else{															
																$default_fields['goals']='Goals';
																$default_fields['reportsummary']='Report Summary';
																$default_fields['in_short']='In Short';
																$default_fields['weight_related_goals']='Weight related goals';
																$default_fields['fitness_related_goals']='Fitness related goals';
																$default_fields['blood_pressure']='Blood pressure';
																$default_fields['Other_notes']='Other notes';
																$default_fields['commit_suggestions']='We agreed you commit to the following suggestions:';
																$default_fields['Nutrition']='Nutrition';
																$default_fields['Hydration']='Hydration';
																$default_fields['Exercise_and_activity']='Exercise and activity';
																$default_fields['Other_consumables ']='Other consumables';
																$default_fields['Sleep']='Sleep';
																$default_fields['Rest']='Rest';
																$default_fields['focus_following_areas']='We agreed that you focus on the following area';
																$default_fields['following_weekly_plan']='We agreed to the following overall/weekly plan';
																$default_fields['motivation1']='You highlighted the following main challenges you face in committing to the above plan';
																$default_fields['motivation2']='We agreed on the following strategies for overcoming these challenges';
														}
														
														$i=1;	
														foreach ( $default_fields as $field_key => $field_value ) {												
															
																
																echo '<div class="row form-group " id="field_'.$i.'"><div class=" col-sm-5"> <input type="text" class="form-control" name="meta_name[]" id="meta_name[]" value="'.$field_key . '" placeholder="Enter Post Meta Name "> </div>		
																<div  class=" col-sm-5">
																<input type="text" class="form-control" name="meta_label[]" id="meta_label[]" value="'.$field_value . '" placeholder="Enter Post Meta Label">													
																</div>
																<div  class=" col-sm-2">';
																?>
																<button class="btn btn-danger btn-xs" onclick="return iv_remove_field('<?php echo $i; ?>');"><?php _e('Delete','epfitness'); ?></button>
																<?php																								
																echo '</div></div>';
															
															$i++;	
															
														}	
													?>
														
													
											</div>				  
										<div class="col-xs-12">											
											<button class="btn btn-warning btn-xs" onclick="return iv_add_field();"> <?php _e('Add More','epfitness'); ?> </button>
									 </div>	
									<input type="hidden" name="dir_name" id="dir_name" value="<?php echo $main_category; ?>">	 
							</form>	
					
									<div class="col-xs-12">					
												<div align="center">
													<div id="loading"></div>
													<button class="btn btn-info btn-lg" onclick="return update_dir_fields();"> <?php _e('Update','epfitness'); ?>  </button>
												</div>
												<p>&nbsp;</p>
											</div>
						</div>							 
				
				</div>			 	
					
					
					
			
					
							
			
									
			  </div>						
		</div>		 


<script>
	var i=<?php echo $i; ?>;
	var ii=<?php echo $ii; ?>;
	
	
	function update_dir_fields(){
		
		var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
		var search_params = {
			"action": 		"ep_fitness_update_report_fields",
			"form_data":	jQuery("#dir_fields").serialize(), 	
		};
		jQuery.ajax({
			url: ajaxurl,
			dataType: "json",
			type: "post",
			data: search_params,
			success: function(response) {              		
				//jQuery("#success_message").html('<h4><span style="color: #04B404;"> ' + response.code + '</span></h4>');
				jQuery('#success_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.code +'.</div>');
			}
		});
	}
	function iv_add_field(){	
	
		jQuery('#custom_field_div').append('<div class="row form-group " id="field_'+i+'"><div class=" col-sm-5"> <input type="text" class="form-control" name="meta_name[]" id="meta_name[]" value="" placeholder="Enter Post Meta Name "> </div>	<div  class=" col-sm-5"><input type="text" class="form-control" name="meta_label[]" id="meta_label[]" value="" placeholder="Enter Post Meta Label"></div><div  class=" col-sm-2"><button class="btn btn-danger btn-xs" onclick="return iv_remove_field('+i+');">Delete</button>');		
			i=i+1;		
	}
	function iv_remove_field(div_id){		
		jQuery("#field_"+div_id).remove();
	}	
	
	
		
</script>				
			
