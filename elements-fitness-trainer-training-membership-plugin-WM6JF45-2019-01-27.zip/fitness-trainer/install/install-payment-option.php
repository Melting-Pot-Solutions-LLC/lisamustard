<?php
update_option('ep_fitness_payment_gateway', 'paypal-express' ); 
update_option('ep_fitness_payment_terms', 'yes' ); 
update_option('ep_fitness_price-table', 'style-1' ); 
update_option('_ep_fitness_api_currency', 'USD' );
update_option('ep_fitness_payment_terms_text', ' I have read & accept the <a href="#" target="_blank"> Terms & Conditions</a>' ); 


?>
