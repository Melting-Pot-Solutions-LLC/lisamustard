   <div class="profile-content">   
	<div class="portlet light">
		  <div class="portlet-title tabbable-line clearfix">
			<div class="caption caption-md">
					  <span class="caption-subject"><?php _e('My Report','epfitness');?>  
						 </span>					  
			</div>						
		  </div>  
		   <div class="clearfix">			  															
					<div class="row">
						 <?php
								$args = array(
								'post_type' => 'fitnessreport', // enter your custom post type												
								'post_status' => 'private',												
								'posts_per_page'=> '999',  // overrides posts per page in theme settings
								'orderby' => 'date',
								'order' => 'ASC',
								);	
								
								$clientid=$current_user->ID;											
								
								$args['meta_query'] = 												
									array(
										'relation' => 'AND',
											array(
												'key'     => 'report_for_user',
												'value'   => $clientid,
												'compare' => '='
											),
										);
								
								$the_query = new WP_Query( $args );
								
								$i=1;
						if ( $the_query->have_posts() ) :

							while ( $the_query->have_posts() ) : $the_query->the_post();
							$id = get_the_ID();
							$con_user=get_post_meta($id,'report_for_user',true);
							$client_user = get_userdata((int)$con_user);
							$display_name=$client_user->user_nicename;
							$name_display=get_user_meta($con_user,'first_name',true).' '.get_user_meta($con_user,'last_name',true);
							if(trim($name_display)==''){$display_name=$client_user->user_nicename;}
							?>
							<div class="col-md-3 col-sm-6 form-group" id="<?php echo $id;?>">		
									<div class="panel panel-default">										
											  <div class="panel-body text-center">
												  
												  <a href="<?php echo get_permalink();?>?&?fitnesspdf=<?php echo $id;?>" target="_blank">								
														<img src="<?php echo wp_ep_fitness_URLPATH. "admin/files/images/pdf.png"; ?>">	
													</a>
													<div class="row" >								
														<div class="col-md-12 col-sm-12 ">		
															<label > <?php echo $display_name;?>  </label>
														</div>	
														<div class="col-md-12 col-sm-12  ">		
															<label > <?php _e('Report','epfitness');?>  </label>
														</div>							
														<div class="col-md-12 col-sm-12 ">				
															<small><?php echo date( 'd M Y', strtotime(get_post_meta($id,'report_date',true))  ); ?> </small>						 
														</div>
													</div>	
													<?php
													$report_access=get_option('epfitness_report_access');	
													if(trim($report_access)==''){$report_access='users';}	
													if($report_access=='users'){		
													?>	
													<div class="row">															
															<div class=" col-md-6  col-xs-6 btn-xs green-haze " style="border-style: solid;border-color:#FFFFFF;">
																<a class="btn btn-xs green-haze" href="?&profile=edit-report&postid=<?php echo $id;?>" role="button"><?php _e('Edit','epfitness');?></a>
															</div>
															<div class=" col-md-6  col-xs-6 btn-xs green-haze " style="border-style: solid;border-color:#FFFFFF;"> 											  
																<a onclick="return delete_report('<?php echo $id;?>');"  class="btn btn-xs green-haze" type="button" target="_blank"><?php _e('Delete','epfitness');?> </a>
															</div>
													</div>	
													<?php
														}
													?>
													
													<div class="row">	
															<div class="col-md-12 btn btn-xs green-haze" style="border-style: solid;border-color:#FFFFFF;">
																 <a href="<?php echo get_permalink();?>?&?fitnesspdf=<?php echo $id;?>" style="color:#FFFFFF;" type="button" target="_blank"><?php _e('View / Download','epfitness');?>  </a>
															</div>
													</div>
																									
											</div>
										</div>		 
							</div>
								
							<?php
							if($i==4){?><div class="row"> </div><?php $i=1;}
							$i++;
							endwhile;
						endif;								
							  ?>
														
					</div>				
								   
			</div>	
		</div>						
	</div>  
<script>
function delete_report(id){
	var cmt = confirm('<?php _e('Do you want to delete the report?','epfitness');?> ');
	if (cmt == true) {
		var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
		var search_params = {
			"action": 		"ep_fitness_delete_report",
			"post_id":	id, 	
		};
		jQuery.ajax({
			url: ajaxurl,
			dataType: "json",
			type: "post",
			data: search_params,
			success: function(response) {              		
				
				jQuery("#"+id).fadeOut(800, function(){ jQuery(this).remove();});
			}
		});
	}


}
</script>	
