<?php
$current_user = wp_get_current_user();
$post_id='';
if(isset($_REQUEST['id'])){
  $post_id=$_REQUEST['id'];
}
$post_data = get_post( $post_id ); 

$day_num='';
if(isset($_REQUEST['cday'])){
  $day_num=$_REQUEST['cday'];
}

?>
<div class="col-sm-12 " id="training_done_button" style="margin-top:30px;">
				<?php				
				$done_status='';
				if($day_num!=''){
					$done_status=get_user_meta($current_user->ID,'_post_done_day_'.$post_id.'_'.$day_num,true);
				}else{
					$done_status=get_user_meta($current_user->ID,'_post_done_'.$post_id,true);
				}
				
				
				if($done_status=='done'){
					echo _e('You have successfully completed the ','epfitness').str_replace('-',' ',$post_data->post_type).'.';
				}else{ ?>
				<button type="button" onclick="done_iv();" class="btn done-training"><?php echo _e('Done','epfitness'); ?></button> 
				<?php
				}
				
			?>


		</div>	
<script>
function done_iv(){

		var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
		var search_params={
			"action"  		: "iv_training_done",
			"post_id" 		: "<?php echo $post_id;?>",
			"day_num" 		: "<?php echo $day_num;?>",
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				if(response.code=='success'){							
					jQuery('#training_done_button').html('<?php echo _e("You have successfully completed the training.","epfitness"); ?>');
				}
			}
		});

}	
</script>
